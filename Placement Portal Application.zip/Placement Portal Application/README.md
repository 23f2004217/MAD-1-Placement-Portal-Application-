# Placement Portal Application - Final Submission

## 📋 Project Overview

The Placement Portal is a comprehensive web application designed for managing campus recruitment processes. It provides role-based interfaces for administrators, companies, and students to streamline placement activities.

## 🚀 Quick Start Guide

### Prerequisites
- Python 3.7 or higher
- pip (Python package installer)

### Installation & Setup

1. **Extract the project files:**
```bash
unzip placement-portal.zip
cd placement-portal
```

2. **Install dependencies:**
```bash
pip install -r requirements.txt
```

3. **Run the application:**
```bash
python app_refactored.py
```

4. **Access the application:**
```
http://127.0.0.1:5000
```

### Default Login Credentials

**Admin Account:**
- Username: `admin`
- Password: `admin123`

**Test Company Account:**
- Email: `hr@techsolutions.com`
- Password: `company123`

**Test Student Accounts:**
- Email: `priya@student.edu` | Password: `student123`
- Email: `rahul@student.edu` | Password: `student123`

## 📁 Project Structure

```
placement-portal/
├── 📄 app_refactored.py          # Main application (refactored)
├── 📄 models.py                  # Database models
├── 📄 config.py                  # Configuration
├── 📄 requirements.txt           # Dependencies
├── 📄 api_documentation.yaml     # API documentation
├── 📄 PROJECT_REPORT.md          # Project report
├── 📄 README_FINAL.md            # This file
│
├── 📁 routes/                    # Blueprint modules
│   ├── auth_routes.py           # Authentication
│   ├── admin_routes.py          # Admin functions
│   ├── company_routes.py        # Company management
│   └── student_routes.py        # Student portal
│
├── 📁 utils/                     # Utility modules
│   ├── decorators.py            # Custom decorators
│   └── helpers.py               # Helper functions
│
├── 📁 templates/                 # HTML templates
│   ├── base.html                # Base template
│   ├── login.html               # Login page
│   ├── register.html            # Registration
│   ├── 📁 admin/                # Admin templates
│   ├── 📁 company/              # Company templates
│   ├── 📁 student/              # Student templates
│   ├── 📁 components/           # Reusable components
│   └── 📁 errors/               # Error pages
│
├── 📁 static/                    # Static files
│   ├── 📁 css/
│   │   └── style.css            # Custom styles
│   └── 📁 uploads/
│       └── 📁 resumes/          # Resume storage
│
└── 📁 instance/                  # Database
    └── placement_portal.db      # SQLite database
```

## 🎯 Key Features

### Authentication System
- Multi-role login (Admin/Company/Student)
- Secure password hashing
- Session-based authentication
- Role-based access control

### Admin Dashboard
- System statistics overview
- Company approval workflow
- Placement drive management
- User search and management
- Pagination for large datasets

### Company Portal
- Registration with approval process
- Placement drive creation and management
- Application review and status updates
- Bulk operations support

### Student Interface
- Self-registration system
- Drive browsing with filters
- Eligibility validation
- Application tracking
- Profile and resume management

## 🔧 Technical Implementation

### Architecture
- **Flask Blueprints**: Modular route organization
- **Application Factory**: Better configuration management
- **SQLAlchemy ORM**: Database abstraction
- **Jinja2 Templates**: Server-side rendering

### Security Features
- Password hashing with Werkzeug
- Role-based access decorators
- Input validation and sanitization
- Secure file upload handling
- CSRF protection

### Database Design
- Proper foreign key relationships
- Cascade delete behavior
- Unique constraints for data integrity
- Optimized queries with pagination

## 🌐 API Documentation

The application provides RESTful APIs documented in OpenAPI 3.0 format. See `api_documentation.yaml` for complete API specification.

### Key Endpoints:
- `POST /login` - User authentication
- `POST /register` - User registration
- `GET /admin/api/stats` - System statistics
- `GET /student/api/drives` - Available drives
- `GET /company/api/applications` - Company applications

## 🧪 Testing Instructions

### Manual Testing Workflow:

1. **Admin Testing:**
   - Login as admin
   - Approve pending companies
   - Approve placement drives
   - Search students/companies
   - Test blacklist functionality

2. **Company Testing:**
   - Register new company
   - Login after admin approval
   - Create placement drives
   - Manage applications
   - Update application statuses

3. **Student Testing:**
   - Register as student
   - Complete profile
   - Browse available drives
   - Apply to eligible drives
   - Track application status

### Sample Data
Run `python add_sample_data.py` to populate the database with test data.

## 📊 Performance Features

- **Pagination**: Efficient handling of large datasets
- **Optimized Queries**: Reduced database load
- **Caching**: Session-based user data caching
- **Responsive Design**: Mobile-friendly interface

## 🔒 Security Measures

- Secure password storage with hashing
- Role-based access control
- Input validation and sanitization
- File upload security (type, size validation)
- Session security with Flask-Login
- Error handling without information disclosure

## 🚀 Deployment Notes

### Development
- Uses SQLite database
- Debug mode enabled
- Automatic database initialization

### Production Considerations
- Change SECRET_KEY to secure random value
- Use production database (PostgreSQL/MySQL)
- Configure HTTPS
- Set up proper logging
- Use WSGI server (Gunicorn, uWSGI)

## 📝 File Descriptions

### Core Application Files
- `app_refactored.py`: Main application with factory pattern
- `models.py`: SQLAlchemy database models
- `config.py`: Application configuration
- `requirements.txt`: Python dependencies

### Route Modules
- `routes/auth_routes.py`: Authentication and registration
- `routes/admin_routes.py`: Admin management functions
- `routes/company_routes.py`: Company drive management
- `routes/student_routes.py`: Student portal functions

### Utility Modules
- `utils/decorators.py`: Custom decorators for security
- `utils/helpers.py`: Helper functions for validation

### Documentation
- `PROJECT_REPORT.md`: Comprehensive project report
- `api_documentation.yaml`: OpenAPI specification
- `README_FINAL.md`: This setup guide

## 🎥 Video Demonstration

The accompanying video demonstrates:
- Complete user workflows for all roles
- Key features and functionality
- Security measures implementation
- API usage examples
- Testing procedures

**Video Link**: [To be provided in submission]

## 🏆 Project Achievements

- ✅ Complete role-based authentication system
- ✅ Comprehensive placement management workflow
- ✅ Secure file upload and data handling
- ✅ Responsive, professional UI design
- ✅ RESTful API implementation
- ✅ Modular, maintainable code architecture
- ✅ Comprehensive error handling
- ✅ Production-ready security measures

## 📞 Support

For technical issues or questions:
1. Check the project documentation
2. Review the code comments
3. Refer to the API documentation
4. Contact the development team

---

**Project Status**: ✅ Complete and Ready for Evaluation
**Architecture**: Production-Quality Flask Application
**Security**: Comprehensive Security Implementation
**Documentation**: Complete with API Specification