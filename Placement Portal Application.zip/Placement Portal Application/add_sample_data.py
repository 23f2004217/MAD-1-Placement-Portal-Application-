from app import app, db
from models import Company, Student, PlacementDrive, Application
from datetime import datetime, timedelta

def add_sample_data():
    with app.app_context():
        # Add sample companies
        company1 = Company(
            company_name='Tech Solutions Inc',
            email='hr@techsolutions.com',
            hr_name='John Smith',
            hr_email='john.smith@techsolutions.com',
            phone='9876543210',
            website='https://techsolutions.com',
            description='Leading technology solutions provider',
            approval_status='Approved'
        )
        company1.set_password('company123')
        
        company2 = Company(
            company_name='Global Innovations',
            email='hr@globalinnovations.com',
            hr_name='Sarah Johnson',
            hr_email='sarah.j@globalinnovations.com',
            phone='9876543211',
            website='https://globalinnovations.com',
            description='Innovation-driven software company',
            approval_status='Pending'
        )
        company2.set_password('company123')
        
        db.session.add_all([company1, company2])
        db.session.commit()
        
        # Add sample students
        student1 = Student(
            name='Rahul Kumar',
            email='rahul@student.edu',
            roll_number='CS2021001',
            branch='Computer Science',
            cgpa=8.5,
            graduation_year=2025,
            contact='9123456789',
            skills='Python, Java, React, SQL'
        )
        student1.set_password('student123')
        
        student2 = Student(
            name='Priya Sharma',
            email='priya@student.edu',
            roll_number='IT2021002',
            branch='Information Technology',
            cgpa=9.2,
            graduation_year=2025,
            contact='9123456790',
            skills='JavaScript, Node.js, MongoDB, AWS'
        )
        student2.set_password('student123')
        
        student3 = Student(
            name='Amit Patel',
            email='amit@student.edu',
            roll_number='EC2021003',
            branch='Electronics',
            cgpa=7.8,
            graduation_year=2025,
            contact='9123456791',
            skills='C++, Embedded Systems, IoT'
        )
        student3.set_password('student123')
        
        db.session.add_all([student1, student2, student3])
        db.session.commit()
        
        # Add sample placement drives
        drive1 = PlacementDrive(
            company_id=company1.id,
            job_title='Software Developer',
            job_description='Develop and maintain web applications using modern technologies',
            eligibility_criteria='Good programming skills and problem-solving ability',
            min_cgpa=7.5,
            allowed_branches='Computer Science, Information Technology',
            salary_package='6-8 LPA',
            location='Bangalore',
            application_deadline=datetime.now() + timedelta(days=15),
            status='Approved'
        )
        
        drive2 = PlacementDrive(
            company_id=company1.id,
            job_title='Data Analyst',
            job_description='Analyze data and create insights for business decisions',
            eligibility_criteria='Strong analytical and statistical skills',
            min_cgpa=8.0,
            allowed_branches='Computer Science, Information Technology, Electronics',
            salary_package='7-9 LPA',
            location='Hyderabad',
            application_deadline=datetime.now() + timedelta(days=20),
            status='Approved'
        )
        
        drive3 = PlacementDrive(
            company_id=company2.id,
            job_title='Full Stack Developer',
            job_description='Work on both frontend and backend development',
            eligibility_criteria='Experience with MERN/MEAN stack',
            min_cgpa=7.0,
            allowed_branches='Computer Science, Information Technology',
            salary_package='8-10 LPA',
            location='Pune',
            application_deadline=datetime.now() + timedelta(days=10),
            status='Pending'
        )
        
        db.session.add_all([drive1, drive2, drive3])
        db.session.commit()
        
        # Add sample applications
        app1 = Application(
            student_id=student1.id,
            drive_id=drive1.id,
            status='Applied'
        )
        
        app2 = Application(
            student_id=student2.id,
            drive_id=drive1.id,
            status='Shortlisted'
        )
        
        app3 = Application(
            student_id=student2.id,
            drive_id=drive2.id,
            status='Applied'
        )
        
        db.session.add_all([app1, app2, app3])
        db.session.commit()
        
        print('Sample data added successfully!')
        print('\nTest Accounts:')
        print('=' * 50)
        print('ADMIN:')
        print('  Username: admin')
        print('  Password: admin123')
        print('\nCOMPANY (Approved):')
        print('  Email: hr@techsolutions.com')
        print('  Password: company123')
        print('\nCOMPANY (Pending):')
        print('  Email: hr@globalinnovations.com')
        print('  Password: company123')
        print('\nSTUDENTS:')
        print('  Email: rahul@student.edu')
        print('  Password: student123')
        print('  (CGPA: 8.5, Branch: Computer Science)')
        print('')
        print('  Email: priya@student.edu')
        print('  Password: student123')
        print('  (CGPA: 9.2, Branch: Information Technology)')
        print('')
        print('  Email: amit@student.edu')
        print('  Password: student123')
        print('  (CGPA: 7.8, Branch: Electronics)')
        print('=' * 50)

if __name__ == '__main__':
    add_sample_data()
