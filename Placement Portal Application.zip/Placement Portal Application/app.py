"""
Refactored Flask Application with Blueprint Architecture
Placement Portal - Production Quality Code
"""
from flask import Flask, render_template, session
from flask_login import LoginManager
from models import db, Admin, Company, Student
from config import Config
import os

# Import Blueprints
from routes.auth_routes import auth_bp
from routes.admin_routes import admin_bp
from routes.company_routes import company_bp
from routes.student_routes import student_bp

def create_app(config_class=Config):
    """
    Application factory pattern for creating Flask app
    
    Args:
        config_class: Configuration class to use
        
    Returns:
        Flask: Configured Flask application
    """
    app = Flask(__name__)
    app.config.from_object(config_class)
    
    # Configure upload settings
    app.config['UPLOAD_FOLDER'] = 'static/uploads/resumes'
    app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size
    
    # Create upload folder if it doesn't exist
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    
    # Initialize extensions
    db.init_app(app)
    
    # Configure Flask-Login
    login_manager = LoginManager()
    login_manager.init_app(app)
    login_manager.login_view = 'auth.login'
    login_manager.login_message = 'Please log in to access this page.'
    login_manager.login_message_category = 'info'
    
    @login_manager.user_loader
    def load_user(user_id):
        """Load user based on session user_type"""
        user_type = session.get('user_type')
        if user_type == 'admin':
            return Admin.query.get(int(user_id))
        elif user_type == 'company':
            return Company.query.get(int(user_id))
        elif user_type == 'student':
            return Student.query.get(int(user_id))
        return None
    
    # Register Blueprints
    app.register_blueprint(auth_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(company_bp)
    app.register_blueprint(student_bp)
    
    # Register error handlers
    register_error_handlers(app)
    
    # Register template filters
    register_template_filters(app)
    
    # Register context processors
    register_context_processors(app)
    
    return app

def register_error_handlers(app):
    """Register custom error handlers"""
    
    @app.errorhandler(403)
    def forbidden_error(error):
        return render_template('errors/403.html'), 403
    
    @app.errorhandler(404)
    def not_found_error(error):
        return render_template('errors/404.html'), 404
    
    @app.errorhandler(405)
    def method_not_allowed_error(error):
        return render_template('errors/404.html'), 405
    
    @app.errorhandler(500)
    def internal_error(error):
        db.session.rollback()
        return render_template('errors/500.html'), 500
    
    @app.errorhandler(413)
    def file_too_large_error(error):
        return render_template('errors/500.html'), 413

def register_template_filters(app):
    """Register custom template filters"""
    
    @app.template_filter('datetime')
    def datetime_filter(date_obj, format='%Y-%m-%d'):
        """Format datetime objects in templates"""
        if date_obj:
            return date_obj.strftime(format)
        return ''
    
    @app.template_filter('status_badge')
    def status_badge_filter(status):
        """Return Bootstrap badge class for status"""
        status_classes = {
            'Pending': 'bg-warning',
            'Approved': 'bg-success',
            'Rejected': 'bg-danger',
            'Closed': 'bg-secondary',
            'Applied': 'bg-primary',
            'Shortlisted': 'bg-info',
            'Selected': 'bg-success',
        }
        return status_classes.get(status, 'bg-secondary')

def register_context_processors(app):
    """Register context processors for templates"""
    
    @app.context_processor
    def inject_user_type():
        """Inject user_type into all templates"""
        return dict(user_type=session.get('user_type'))
    
    @app.context_processor
    def inject_app_info():
        """Inject application information"""
        return dict(
            app_name='Placement Portal',
            app_version='2.0.0',
            current_year=2026
        )

def init_database(app):
    """Initialize database with default data"""
    with app.app_context():
        # Create all tables
        db.create_all()
        
        # Create default admin if not exists
        if not Admin.query.filter_by(username='admin').first():
            admin = Admin(username='admin')
            admin.set_password('admin123')
            db.session.add(admin)
            db.session.commit()
            print('✓ Default admin created: username=admin, password=admin123')
        else:
            print('✓ Admin user already exists')

# Create the application instance
app = create_app()

if __name__ == '__main__':
    # Initialize database
    init_database(app)
    
    # Run the application
    print('🚀 Starting Placement Portal Application...')
    print('📊 Admin Dashboard: http://127.0.0.1:5000/admin/dashboard')
    print('🏢 Company Portal: http://127.0.0.1:5000/company/dashboard')
    print('🎓 Student Portal: http://127.0.0.1:5000/student/dashboard')
    print('🔐 Login: http://127.0.0.1:5000/login')
    
    app.run(debug=True, host='127.0.0.1', port=5000)