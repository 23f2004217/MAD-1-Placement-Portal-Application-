"""
Admin routes for managing companies, students, and placement drives
"""
from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from flask_login import login_required, current_user
from models import db, Company, Student, PlacementDrive, Application
from utils.decorators import role_required
from utils.helpers import get_pagination_info
from sqlalchemy import or_

admin_bp = Blueprint('admin', __name__, url_prefix='/admin')

@admin_bp.route('/dashboard')
@admin_bp.route('/dashboard/<int:page>')
@login_required
@role_required('admin')
def dashboard(page=1):
    """Admin dashboard with pagination"""
    per_page = 10
    
    # Get paginated data
    companies_pagination = Company.query.paginate(
        page=page, per_page=per_page, error_out=False
    )
    students_pagination = Student.query.paginate(
        page=page, per_page=per_page, error_out=False
    )
    drives_pagination = PlacementDrive.query.paginate(
        page=page, per_page=per_page, error_out=False
    )
    
    # Get statistics
    stats = {
        'total_students': Student.query.count(),
        'total_companies': Company.query.count(),
        'total_drives': PlacementDrive.query.count(),
        'total_applications': Application.query.count(),
        'pending_companies': Company.query.filter_by(approval_status='Pending').count(),
        'pending_drives': PlacementDrive.query.filter_by(status='Pending').count(),
        'approved_drives': PlacementDrive.query.filter_by(status='Approved').count()
    }
    
    return render_template('admin/dashboard.html',
                         companies=companies_pagination.items,
                         students=students_pagination.items,
                         drives=drives_pagination.items,
                         companies_pagination=companies_pagination,
                         students_pagination=students_pagination,
                         drives_pagination=drives_pagination,
                         stats=stats,
                         current_page=page)

@admin_bp.route('/companies')
@admin_bp.route('/companies/<int:page>')
@login_required
@role_required('admin')
def companies(page=1):
    """View all companies with pagination"""
    per_page = 15
    companies_pagination = Company.query.order_by(Company.created_at.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )
    
    return render_template('admin/companies.html',
                         companies=companies_pagination.items,
                         pagination=companies_pagination)

@admin_bp.route('/students')
@admin_bp.route('/students/<int:page>')
@login_required
@role_required('admin')
def students(page=1):
    """View all students with pagination"""
    per_page = 15
    students_pagination = Student.query.order_by(Student.created_at.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )
    
    return render_template('admin/students.html',
                         students=students_pagination.items,
                         pagination=students_pagination)

@admin_bp.route('/drives')
@admin_bp.route('/drives/<int:page>')
@login_required
@role_required('admin')
def drives(page=1):
    """View all placement drives with pagination"""
    per_page = 15
    drives_pagination = PlacementDrive.query.order_by(PlacementDrive.created_at.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )
    
    return render_template('admin/drives.html',
                         drives=drives_pagination.items,
                         pagination=drives_pagination)

@admin_bp.route('/applications')
@admin_bp.route('/applications/<int:page>')
@login_required
@role_required('admin')
def applications(page=1):
    """View all applications with pagination"""
    per_page = 20
    applications_pagination = Application.query.order_by(Application.application_date.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )
    
    return render_template('admin/applications.html',
                         applications=applications_pagination.items,
                         pagination=applications_pagination)

@admin_bp.route('/approve_company/<int:company_id>')
@login_required
@role_required('admin')
def approve_company(company_id):
    """Approve a company registration"""
    try:
        company = Company.query.get_or_404(company_id)
        company.approval_status = 'Approved'
        db.session.commit()
        flash(f'{company.company_name} approved successfully', 'success')
    except Exception as e:
        db.session.rollback()
        flash('Error approving company', 'danger')
    
    return redirect(request.referrer or url_for('admin.dashboard'))

@admin_bp.route('/reject_company/<int:company_id>')
@login_required
@role_required('admin')
def reject_company(company_id):
    """Reject a company registration"""
    try:
        company = Company.query.get_or_404(company_id)
        company.approval_status = 'Rejected'
        db.session.commit()
        flash(f'{company.company_name} rejected', 'warning')
    except Exception as e:
        db.session.rollback()
        flash('Error rejecting company', 'danger')
    
    return redirect(request.referrer or url_for('admin.dashboard'))

@admin_bp.route('/approve_drive/<int:drive_id>')
@login_required
@role_required('admin')
def approve_drive(drive_id):
    """Approve a placement drive"""
    try:
        drive = PlacementDrive.query.get_or_404(drive_id)
        drive.status = 'Approved'
        db.session.commit()
        flash('Drive approved successfully', 'success')
    except Exception as e:
        db.session.rollback()
        flash('Error approving drive', 'danger')
    
    return redirect(request.referrer or url_for('admin.dashboard'))

@admin_bp.route('/reject_drive/<int:drive_id>')
@login_required
@role_required('admin')
def reject_drive(drive_id):
    """Reject a placement drive"""
    try:
        drive = PlacementDrive.query.get_or_404(drive_id)
        drive.status = 'Rejected'
        db.session.commit()
        flash('Drive rejected', 'warning')
    except Exception as e:
        db.session.rollback()
        flash('Error rejecting drive', 'danger')
    
    return redirect(request.referrer or url_for('admin.dashboard'))

@admin_bp.route('/search', methods=['GET', 'POST'])
@login_required
@role_required('admin')
def search():
    """Search students and companies"""
    results = {'students': [], 'companies': []}
    query = ''
    search_type = ''
    
    if request.method == 'POST':
        search_type = request.form.get('search_type', '')
        query = request.form.get('query', '').strip()
        
        if query:
            if search_type == 'student':
                results['students'] = Student.query.filter(
                    or_(
                        Student.name.ilike(f'%{query}%'),
                        Student.roll_number.ilike(f'%{query}%'),
                        Student.contact.ilike(f'%{query}%'),
                        Student.email.ilike(f'%{query}%')
                    )
                ).limit(50).all()
            elif search_type == 'company':
                results['companies'] = Company.query.filter(
                    or_(
                        Company.company_name.ilike(f'%{query}%'),
                        Company.email.ilike(f'%{query}%')
                    )
                ).limit(50).all()
    
    return render_template('admin/search.html',
                         results=results,
                         query=query,
                         search_type=search_type)

@admin_bp.route('/blacklist_student/<int:student_id>')
@login_required
@role_required('admin')
def blacklist_student(student_id):
    """Toggle student blacklist status"""
    try:
        student = Student.query.get_or_404(student_id)
        student.is_blacklisted = not student.is_blacklisted
        db.session.commit()
        
        status = 'blacklisted' if student.is_blacklisted else 'activated'
        flash(f'Student {student.name} {status} successfully', 'success')
    except Exception as e:
        db.session.rollback()
        flash('Error updating student status', 'danger')
    
    return redirect(request.referrer or url_for('admin.dashboard'))

@admin_bp.route('/blacklist_company/<int:company_id>')
@login_required
@role_required('admin')
def blacklist_company(company_id):
    """Toggle company blacklist status"""
    try:
        company = Company.query.get_or_404(company_id)
        company.is_blacklisted = not company.is_blacklisted
        db.session.commit()
        
        status = 'blacklisted' if company.is_blacklisted else 'activated'
        flash(f'Company {company.company_name} {status} successfully', 'success')
    except Exception as e:
        db.session.rollback()
        flash('Error updating company status', 'danger')
    
    return redirect(request.referrer or url_for('admin.dashboard'))

@admin_bp.route('/delete_student/<int:student_id>')
@login_required
@role_required('admin')
def delete_student(student_id):
    """Delete a student (with confirmation)"""
    try:
        student = Student.query.get_or_404(student_id)
        student_name = student.name
        db.session.delete(student)
        db.session.commit()
        flash(f'Student {student_name} deleted successfully', 'success')
    except Exception as e:
        db.session.rollback()
        flash('Error deleting student', 'danger')
    
    return redirect(request.referrer or url_for('admin.dashboard'))

@admin_bp.route('/delete_company/<int:company_id>')
@login_required
@role_required('admin')
def delete_company(company_id):
    """Delete a company (with confirmation)"""
    try:
        company = Company.query.get_or_404(company_id)
        company_name = company.company_name
        db.session.delete(company)
        db.session.commit()
        flash(f'Company {company_name} deleted successfully', 'success')
    except Exception as e:
        db.session.rollback()
        flash('Error deleting company', 'danger')
    
    return redirect(request.referrer or url_for('admin.dashboard'))

# API Endpoints
@admin_bp.route('/api/stats')
@login_required
@role_required('admin')
def api_stats():
    """Get admin statistics"""
    return jsonify({
        'total_students': Student.query.count(),
        'total_companies': Company.query.count(),
        'total_drives': PlacementDrive.query.count(),
        'total_applications': Application.query.count(),
        'pending_companies': Company.query.filter_by(approval_status='Pending').count(),
        'pending_drives': PlacementDrive.query.filter_by(status='Pending').count(),
        'approved_drives': PlacementDrive.query.filter_by(status='Approved').count()
    })

@admin_bp.route('/api/students')
@login_required
@role_required('admin')
def api_students():
    """Get all students data"""
    students = Student.query.all()
    return jsonify([{
        'id': s.id,
        'name': s.name,
        'email': s.email,
        'roll_number': s.roll_number,
        'branch': s.branch,
        'cgpa': s.cgpa,
        'graduation_year': s.graduation_year,
        'skills': s.skills,
        'contact': s.contact,
        'is_blacklisted': s.is_blacklisted,
        'created_at': s.created_at.strftime('%Y-%m-%d') if s.created_at else None
    } for s in students])

@admin_bp.route('/api/companies')
@login_required
@role_required('admin')
def api_companies():
    """Get all companies data"""
    companies = Company.query.all()
    return jsonify([{
        'id': c.id,
        'company_name': c.company_name,
        'email': c.email,
        'hr_name': c.hr_name,
        'hr_email': c.hr_email,
        'phone': c.phone,
        'website': c.website,
        'description': c.description,
        'approval_status': c.approval_status,
        'is_blacklisted': c.is_blacklisted,
        'created_at': c.created_at.strftime('%Y-%m-%d') if c.created_at else None
    } for c in companies])