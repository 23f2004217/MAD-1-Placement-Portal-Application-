"""
Authentication routes for login, logout, and registration
"""
from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from flask_login import login_user, logout_user, login_required
from models import db, Admin, Company, Student
from utils.decorators import validate_form_data
from utils.helpers import validate_cgpa, validate_graduation_year
from datetime import datetime

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/')
def index():
    """Redirect to login page"""
    return redirect(url_for('auth.login'))

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    """Handle user login for all roles"""
    if request.method == 'POST':
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '')
        user_type = request.form.get('user_type', '')
        
        # Validate input
        if not all([email, password, user_type]):
            flash('All fields are required', 'danger')
            return render_template('login.html')
        
        user = None
        
        # Authenticate based on user type
        if user_type == 'admin':
            user = Admin.query.filter_by(username=email).first()
        elif user_type == 'company':
            user = Company.query.filter_by(email=email).first()
            if user:
                if user.approval_status != 'Approved':
                    flash('Your account is pending approval', 'warning')
                    return render_template('login.html')
                if user.is_blacklisted:
                    flash('Your account has been deactivated', 'danger')
                    return render_template('login.html')
        elif user_type == 'student':
            user = Student.query.filter_by(email=email).first()
            if user and user.is_blacklisted:
                flash('Your account has been deactivated', 'danger')
                return render_template('login.html')
        else:
            flash('Invalid user type', 'danger')
            return render_template('login.html')
        
        # Check credentials
        if user and user.check_password(password):
            login_user(user)
            session['user_type'] = user_type
            return redirect(url_for(f'{user_type}.dashboard'))
        else:
            flash('Invalid credentials', 'danger')
    
    return render_template('login.html')

@auth_bp.route('/register', methods=['GET', 'POST'])
@validate_form_data
def register():
    """Handle user registration for companies and students"""
    if request.method == 'POST':
        user_type = request.form.get('user_type', '')
        
        if user_type == 'company':
            return _register_company()
        elif user_type == 'student':
            return _register_student()
        else:
            flash('Invalid user type', 'danger')
    
    return render_template('register.html')

def _register_company():
    """Register a new company"""
    try:
        # Check if email already exists
        existing_company = Company.query.filter_by(email=request.form.get('email')).first()
        if existing_company:
            flash('Email already registered', 'danger')
            return render_template('register.html')
        
        company = Company(
            company_name=request.form.get('company_name', '').strip(),
            email=request.form.get('email', '').strip(),
            hr_name=request.form.get('hr_name', '').strip(),
            hr_email=request.form.get('hr_email', '').strip(),
            phone=request.form.get('phone', '').strip(),
            website=request.form.get('website', '').strip(),
            description=request.form.get('description', '').strip()
        )
        company.set_password(request.form.get('password', ''))
        
        db.session.add(company)
        db.session.commit()
        flash('Registration successful! Wait for admin approval', 'success')
        return redirect(url_for('auth.login'))
        
    except Exception as e:
        db.session.rollback()
        flash('Registration failed. Please try again.', 'danger')
        return render_template('register.html')

def _register_student():
    """Register a new student"""
    try:
        # Validate CGPA
        cgpa = float(request.form.get('cgpa', 0))
        if not validate_cgpa(cgpa):
            flash('CGPA must be between 0 and 10', 'danger')
            return render_template('register.html')
        
        # Validate graduation year
        grad_year = int(request.form.get('graduation_year', 0))
        if not validate_graduation_year(grad_year):
            current_year = datetime.now().year
            flash(f'Graduation year must be between {current_year} and {current_year + 10}', 'danger')
            return render_template('register.html')
        
        # Check if email or roll number already exists
        existing_student = Student.query.filter(
            (Student.email == request.form.get('email')) |
            (Student.roll_number == request.form.get('roll_number'))
        ).first()
        
        if existing_student:
            flash('Email or roll number already registered', 'danger')
            return render_template('register.html')
        
        student = Student(
            name=request.form.get('name', '').strip(),
            email=request.form.get('email', '').strip(),
            roll_number=request.form.get('roll_number', '').strip(),
            branch=request.form.get('branch', '').strip(),
            cgpa=cgpa,
            graduation_year=grad_year,
            contact=request.form.get('contact', '').strip(),
            skills=request.form.get('skills', '').strip()
        )
        student.set_password(request.form.get('password', ''))
        
        db.session.add(student)
        db.session.commit()
        flash('Registration successful! You can now login', 'success')
        return redirect(url_for('auth.login'))
        
    except ValueError:
        flash('Invalid CGPA or graduation year format', 'danger')
        return render_template('register.html')
    except Exception as e:
        db.session.rollback()
        flash('Registration failed. Please try again.', 'danger')
        return render_template('register.html')

@auth_bp.route('/logout')
@login_required
def logout():
    """Handle user logout"""
    session.pop('user_type', None)
    logout_user()
    flash('You have been logged out successfully', 'info')
    return redirect(url_for('auth.login'))