"""
Company routes for managing placement drives and applications
"""
from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from flask_login import login_required, current_user
from models import db, PlacementDrive, Application
from utils.decorators import role_required
from utils.helpers import validate_cgpa, validate_deadline
from datetime import datetime

company_bp = Blueprint('company', __name__, url_prefix='/company')

@company_bp.route('/dashboard')
@company_bp.route('/dashboard/<int:page>')
@login_required
@role_required('company')
def dashboard(page=1):
    """Company dashboard with paginated drives"""
    per_page = 10
    drives_pagination = PlacementDrive.query.filter_by(company_id=current_user.id)\
        .order_by(PlacementDrive.created_at.desc())\
        .paginate(page=page, per_page=per_page, error_out=False)
    
    # Get statistics
    stats = {
        'total_drives': PlacementDrive.query.filter_by(company_id=current_user.id).count(),
        'approved_drives': PlacementDrive.query.filter_by(
            company_id=current_user.id, status='Approved'
        ).count(),
        'pending_drives': PlacementDrive.query.filter_by(
            company_id=current_user.id, status='Pending'
        ).count(),
        'total_applications': Application.query.join(PlacementDrive)\
            .filter(PlacementDrive.company_id == current_user.id).count()
    }
    
    return render_template('company/dashboard.html',
                         drives=drives_pagination.items,
                         pagination=drives_pagination,
                         stats=stats)

@company_bp.route('/create_drive', methods=['GET', 'POST'])
@login_required
@role_required('company')
def create_drive():
    """Create a new placement drive"""
    # Check if company is approved
    if current_user.approval_status != 'Approved':
        flash('You must be approved by admin to create drives', 'warning')
        return redirect(url_for('company.dashboard'))
    
    if request.method == 'POST':
        try:
            # Validate minimum CGPA
            min_cgpa = float(request.form.get('min_cgpa', 0))
            if not validate_cgpa(min_cgpa):
                flash('Minimum CGPA must be between 0 and 10', 'danger')
                return render_template('company/create_drive.html')
            
            # Validate deadline
            deadline_str = request.form.get('application_deadline', '').strip()
            deadline = None
            if deadline_str:
                deadline = datetime.strptime(deadline_str, '%Y-%m-%d')
                if not validate_deadline(deadline):
                    flash('Application deadline cannot be in the past', 'danger')
                    return render_template('company/create_drive.html')
            
            # Create new drive
            drive = PlacementDrive(
                company_id=current_user.id,
                job_title=request.form.get('job_title', '').strip(),
                job_description=request.form.get('job_description', '').strip(),
                eligibility_criteria=request.form.get('eligibility_criteria', '').strip(),
                min_cgpa=min_cgpa,
                allowed_branches=request.form.get('allowed_branches', '').strip(),
                salary_package=request.form.get('salary_package', '').strip(),
                location=request.form.get('location', '').strip(),
                application_deadline=deadline
            )
            
            db.session.add(drive)
            db.session.commit()
            flash('Drive created successfully! Waiting for admin approval', 'success')
            return redirect(url_for('company.dashboard'))
            
        except ValueError:
            flash('Invalid CGPA format', 'danger')
        except Exception as e:
            db.session.rollback()
            flash('Error creating drive. Please try again.', 'danger')
    
    return render_template('company/create_drive.html')

@company_bp.route('/edit_drive/<int:drive_id>', methods=['GET', 'POST'])
@login_required
@role_required('company')
def edit_drive(drive_id):
    """Edit an existing placement drive"""
    drive = PlacementDrive.query.get_or_404(drive_id)
    
    # Check ownership
    if drive.company_id != current_user.id:
        flash('Access denied', 'danger')
        return redirect(url_for('company.dashboard'))
    
    if request.method == 'POST':
        try:
            # Validate minimum CGPA
            min_cgpa = float(request.form.get('min_cgpa', 0))
            if not validate_cgpa(min_cgpa):
                flash('Minimum CGPA must be between 0 and 10', 'danger')
                return render_template('company/edit_drive.html', drive=drive)
            
            # Validate deadline
            deadline_str = request.form.get('application_deadline', '').strip()
            deadline = None
            if deadline_str:
                deadline = datetime.strptime(deadline_str, '%Y-%m-%d')
                if not validate_deadline(deadline):
                    flash('Application deadline cannot be in the past', 'danger')
                    return render_template('company/edit_drive.html', drive=drive)
            
            # Update drive
            drive.job_title = request.form.get('job_title', '').strip()
            drive.job_description = request.form.get('job_description', '').strip()
            drive.eligibility_criteria = request.form.get('eligibility_criteria', '').strip()
            drive.min_cgpa = min_cgpa
            drive.allowed_branches = request.form.get('allowed_branches', '').strip()
            drive.salary_package = request.form.get('salary_package', '').strip()
            drive.location = request.form.get('location', '').strip()
            drive.application_deadline = deadline
            
            db.session.commit()
            flash('Drive updated successfully', 'success')
            return redirect(url_for('company.dashboard'))
            
        except ValueError:
            flash('Invalid CGPA format', 'danger')
        except Exception as e:
            db.session.rollback()
            flash('Error updating drive. Please try again.', 'danger')
    
    return render_template('company/edit_drive.html', drive=drive)

@company_bp.route('/delete_drive/<int:drive_id>')
@login_required
@role_required('company')
def delete_drive(drive_id):
    """Delete a placement drive"""
    try:
        drive = PlacementDrive.query.get_or_404(drive_id)
        
        # Check ownership
        if drive.company_id != current_user.id:
            flash('Access denied', 'danger')
            return redirect(url_for('company.dashboard'))
        
        drive_title = drive.job_title
        db.session.delete(drive)
        db.session.commit()
        flash(f'Drive "{drive_title}" deleted successfully', 'success')
        
    except Exception as e:
        db.session.rollback()
        flash('Error deleting drive', 'danger')
    
    return redirect(url_for('company.dashboard'))

@company_bp.route('/close_drive/<int:drive_id>')
@login_required
@role_required('company')
def close_drive(drive_id):
    """Close a placement drive"""
    try:
        drive = PlacementDrive.query.get_or_404(drive_id)
        
        # Check ownership
        if drive.company_id != current_user.id:
            flash('Access denied', 'danger')
            return redirect(url_for('company.dashboard'))
        
        drive.status = 'Closed'
        db.session.commit()
        flash(f'Drive "{drive.job_title}" closed successfully', 'success')
        
    except Exception as e:
        db.session.rollback()
        flash('Error closing drive', 'danger')
    
    return redirect(url_for('company.dashboard'))

@company_bp.route('/view_applications/<int:drive_id>')
@company_bp.route('/view_applications/<int:drive_id>/<int:page>')
@login_required
@role_required('company')
def view_applications(drive_id, page=1):
    """View applications for a specific drive with pagination"""
    drive = PlacementDrive.query.get_or_404(drive_id)
    
    # Check ownership
    if drive.company_id != current_user.id:
        flash('Access denied', 'danger')
        return redirect(url_for('company.dashboard'))
    
    per_page = 15
    applications_pagination = Application.query.filter_by(drive_id=drive_id)\
        .order_by(Application.application_date.desc())\
        .paginate(page=page, per_page=per_page, error_out=False)
    
    # Get application statistics
    stats = {
        'total': Application.query.filter_by(drive_id=drive_id).count(),
        'applied': Application.query.filter_by(drive_id=drive_id, status='Applied').count(),
        'shortlisted': Application.query.filter_by(drive_id=drive_id, status='Shortlisted').count(),
        'selected': Application.query.filter_by(drive_id=drive_id, status='Selected').count(),
        'rejected': Application.query.filter_by(drive_id=drive_id, status='Rejected').count()
    }
    
    return render_template('company/applications.html',
                         drive=drive,
                         applications=applications_pagination.items,
                         pagination=applications_pagination,
                         stats=stats)

@company_bp.route('/update_application/<int:app_id>/<status>')
@login_required
@role_required('company')
def update_application(app_id, status):
    """Update application status"""
    try:
        application = Application.query.get_or_404(app_id)
        drive = application.drive
        
        # Check ownership
        if drive.company_id != current_user.id:
            flash('Access denied', 'danger')
            return redirect(url_for('company.dashboard'))
        
        # Validate status
        valid_statuses = ['Applied', 'Shortlisted', 'Selected', 'Rejected']
        if status not in valid_statuses:
            flash('Invalid status', 'danger')
            return redirect(url_for('company.view_applications', drive_id=drive.id))
        
        application.status = status
        db.session.commit()
        flash(f'Application status updated to {status}', 'success')
        
    except Exception as e:
        db.session.rollback()
        flash('Error updating application status', 'danger')
    
    return redirect(url_for('company.view_applications', drive_id=application.drive_id))

@company_bp.route('/bulk_update_applications', methods=['POST'])
@login_required
@role_required('company')
def bulk_update_applications():
    """Bulk update application statuses"""
    try:
        application_ids = request.form.getlist('application_ids')
        new_status = request.form.get('status')
        
        if not application_ids or not new_status:
            flash('Please select applications and status', 'danger')
            return redirect(request.referrer)
        
        # Validate status
        valid_statuses = ['Applied', 'Shortlisted', 'Selected', 'Rejected']
        if new_status not in valid_statuses:
            flash('Invalid status', 'danger')
            return redirect(request.referrer)
        
        # Update applications
        updated_count = 0
        for app_id in application_ids:
            application = Application.query.get(app_id)
            if application and application.drive.company_id == current_user.id:
                application.status = new_status
                updated_count += 1
        
        db.session.commit()
        flash(f'{updated_count} applications updated to {new_status}', 'success')
        
    except Exception as e:
        db.session.rollback()
        flash('Error updating applications', 'danger')
    
    return redirect(request.referrer or url_for('company.dashboard'))

# API Endpoints
@company_bp.route('/api/drives')
@login_required
@role_required('company')
def api_drives():
    """Get company's drives data"""
    drives = PlacementDrive.query.filter_by(company_id=current_user.id).all()
    return jsonify([{
        'id': d.id,
        'job_title': d.job_title,
        'job_description': d.job_description,
        'eligibility_criteria': d.eligibility_criteria,
        'min_cgpa': d.min_cgpa,
        'allowed_branches': d.allowed_branches,
        'salary_package': d.salary_package,
        'location': d.location,
        'application_deadline': d.application_deadline.strftime('%Y-%m-%d') if d.application_deadline else None,
        'status': d.status,
        'applications_count': len(d.applications),
        'created_at': d.created_at.strftime('%Y-%m-%d') if d.created_at else None
    } for d in drives])

@company_bp.route('/api/applications')
@login_required
@role_required('company')
def api_applications():
    """Get company's applications data"""
    drive_ids = [d.id for d in PlacementDrive.query.filter_by(company_id=current_user.id).all()]
    applications = Application.query.filter(Application.drive_id.in_(drive_ids)).all()
    
    return jsonify([{
        'id': a.id,
        'student_name': a.student.name,
        'student_roll': a.student.roll_number,
        'drive_title': a.drive.job_title,
        'application_date': a.application_date.strftime('%Y-%m-%d'),
        'status': a.status
    } for a in applications])