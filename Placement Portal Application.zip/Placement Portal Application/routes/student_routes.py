"""
Student routes for viewing drives, applying, and managing profile
"""
from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from flask_login import login_required, current_user
from models import db, PlacementDrive, Application
from utils.decorators import role_required
from utils.helpers import validate_cgpa, validate_graduation_year, allowed_file
from werkzeug.utils import secure_filename
from datetime import datetime
import os

student_bp = Blueprint('student', __name__, url_prefix='/student')

@student_bp.route('/dashboard')
@student_bp.route('/dashboard/<int:page>')
@login_required
@role_required('student')
def dashboard(page=1):
    """Student dashboard with available drives and applications"""
    per_page = 12
    
    # Get approved drives with pagination
    drives_pagination = PlacementDrive.query.filter_by(status='Approved')\
        .order_by(PlacementDrive.created_at.desc())\
        .paginate(page=page, per_page=per_page, error_out=False)
    
    # Get student's applications
    applications = Application.query.filter_by(student_id=current_user.id)\
        .order_by(Application.application_date.desc()).all()
    applied_drive_ids = [app.drive_id for app in applications]
    
    # Get statistics
    stats = {
        'total_drives': PlacementDrive.query.filter_by(status='Approved').count(),
        'applied_drives': len(applications),
        'shortlisted': len([a for a in applications if a.status == 'Shortlisted']),
        'selected': len([a for a in applications if a.status == 'Selected'])
    }
    
    return render_template('student/dashboard.html',
                         drives=drives_pagination.items,
                         pagination=drives_pagination,
                         applications=applications[:5],  # Show recent 5
                         applied_drive_ids=applied_drive_ids,
                         stats=stats)

@student_bp.route('/drives')
@student_bp.route('/drives/<int:page>')
@login_required
@role_required('student')
def drives(page=1):
    """View all available drives with pagination and filtering"""
    per_page = 15
    
    # Get filter parameters
    branch_filter = request.args.get('branch', '')
    min_cgpa_filter = request.args.get('min_cgpa', '')
    location_filter = request.args.get('location', '')
    
    # Build query
    query = PlacementDrive.query.filter_by(status='Approved')
    
    # Apply filters
    if branch_filter:
        query = query.filter(PlacementDrive.allowed_branches.ilike(f'%{branch_filter}%'))
    
    if min_cgpa_filter:
        try:
            min_cgpa = float(min_cgpa_filter)
            query = query.filter(PlacementDrive.min_cgpa <= min_cgpa)
        except ValueError:
            pass
    
    if location_filter:
        query = query.filter(PlacementDrive.location.ilike(f'%{location_filter}%'))
    
    drives_pagination = query.order_by(PlacementDrive.created_at.desc())\
        .paginate(page=page, per_page=per_page, error_out=False)
    
    # Get applied drive IDs
    applied_drive_ids = [app.drive_id for app in 
                        Application.query.filter_by(student_id=current_user.id).all()]
    
    return render_template('student/drives.html',
                         drives=drives_pagination.items,
                         pagination=drives_pagination,
                         applied_drive_ids=applied_drive_ids,
                         filters={
                             'branch': branch_filter,
                             'min_cgpa': min_cgpa_filter,
                             'location': location_filter
                         })

@student_bp.route('/apply/<int:drive_id>')
@login_required
@role_required('student')
def apply_drive(drive_id):
    """Apply to a placement drive"""
    try:
        drive = PlacementDrive.query.get_or_404(drive_id)
        
        # Check if drive is approved
        if drive.status != 'Approved':
            flash('This drive is not available for applications', 'warning')
            return redirect(url_for('student.dashboard'))
        
        # Check deadline
        if drive.application_deadline and datetime.now() > drive.application_deadline:
            flash('Application deadline has passed', 'danger')
            return redirect(url_for('student.dashboard'))
        
        # Check CGPA eligibility
        if drive.min_cgpa and current_user.cgpa and current_user.cgpa < drive.min_cgpa:
            flash(f'Your CGPA ({current_user.cgpa}) does not meet the minimum requirement ({drive.min_cgpa})', 'danger')
            return redirect(url_for('student.dashboard'))
        
        # Check branch eligibility
        if drive.allowed_branches and current_user.branch:
            allowed_branches = [b.strip() for b in drive.allowed_branches.split(',')]
            if current_user.branch not in allowed_branches:
                flash(f'Your branch ({current_user.branch}) is not eligible for this drive', 'danger')
                return redirect(url_for('student.dashboard'))
        
        # Check for duplicate application
        existing = Application.query.filter_by(
            student_id=current_user.id, 
            drive_id=drive_id
        ).first()
        
        if existing:
            flash('You have already applied to this drive', 'warning')
        else:
            # Create application
            application = Application(
                student_id=current_user.id,
                drive_id=drive_id
            )
            db.session.add(application)
            db.session.commit()
            flash(f'Successfully applied to {drive.job_title}', 'success')
            
    except Exception as e:
        db.session.rollback()
        flash('Error submitting application. Please try again.', 'danger')
    
    return redirect(url_for('student.dashboard'))

@student_bp.route('/withdraw/<int:drive_id>')
@login_required
@role_required('student')
def withdraw_application(drive_id):
    """Withdraw application from a drive"""
    try:
        application = Application.query.filter_by(
            student_id=current_user.id,
            drive_id=drive_id
        ).first()
        
        if not application:
            flash('Application not found', 'danger')
            return redirect(url_for('student.dashboard'))
        
        # Only allow withdrawal if status is 'Applied'
        if application.status != 'Applied':
            flash('Cannot withdraw application at this stage', 'warning')
            return redirect(url_for('student.dashboard'))
        
        drive_title = application.drive.job_title
        db.session.delete(application)
        db.session.commit()
        flash(f'Application withdrawn from {drive_title}', 'info')
        
    except Exception as e:
        db.session.rollback()
        flash('Error withdrawing application', 'danger')
    
    return redirect(url_for('student.dashboard'))

@student_bp.route('/profile', methods=['GET', 'POST'])
@login_required
@role_required('student')
def profile():
    """View and edit student profile"""
    if request.method == 'POST':
        try:
            # Validate CGPA
            cgpa = float(request.form.get('cgpa', 0))
            if not validate_cgpa(cgpa):
                flash('CGPA must be between 0 and 10', 'danger')
                return render_template('student/profile.html')
            
            # Validate graduation year
            grad_year = int(request.form.get('graduation_year', 0))
            if not validate_graduation_year(grad_year):
                current_year = datetime.now().year
                flash(f'Graduation year must be between {current_year} and {current_year + 10}', 'danger')
                return render_template('student/profile.html')
            
            # Update profile
            current_user.name = request.form.get('name', '').strip()
            current_user.branch = request.form.get('branch', '').strip()
            current_user.cgpa = cgpa
            current_user.graduation_year = grad_year
            current_user.contact = request.form.get('contact', '').strip()
            current_user.skills = request.form.get('skills', '').strip()
            
            # Handle resume upload
            if 'resume' in request.files:
                file = request.files['resume']
                if file and file.filename and allowed_file(file.filename):
                    # Create upload directory if it doesn't exist
                    upload_dir = os.path.join('static', 'uploads', 'resumes')
                    os.makedirs(upload_dir, exist_ok=True)
                    
                    # Generate secure filename
                    filename = secure_filename(f"{current_user.roll_number}_{file.filename}")
                    file_path = os.path.join(upload_dir, filename)
                    
                    # Remove old resume if exists
                    if current_user.resume_path:
                        old_file_path = os.path.join(upload_dir, current_user.resume_path)
                        if os.path.exists(old_file_path):
                            os.remove(old_file_path)
                    
                    # Save new resume
                    file.save(file_path)
                    current_user.resume_path = filename
                    flash('Resume uploaded successfully', 'success')
                elif file.filename:
                    flash('Invalid file type. Only PDF, DOC, and DOCX files are allowed', 'danger')
            
            db.session.commit()
            flash('Profile updated successfully', 'success')
            return redirect(url_for('student.dashboard'))
            
        except ValueError:
            flash('Invalid CGPA or graduation year format', 'danger')
        except Exception as e:
            db.session.rollback()
            flash('Error updating profile. Please try again.', 'danger')
    
    return render_template('student/profile.html')

@student_bp.route('/history')
@student_bp.route('/history/<int:page>')
@login_required
@role_required('student')
def history(page=1):
    """View application history with pagination"""
    per_page = 15
    applications_pagination = Application.query.filter_by(student_id=current_user.id)\
        .order_by(Application.application_date.desc())\
        .paginate(page=page, per_page=per_page, error_out=False)
    
    # Get statistics
    applications = Application.query.filter_by(student_id=current_user.id).all()
    stats = {
        'total': len(applications),
        'applied': len([a for a in applications if a.status == 'Applied']),
        'shortlisted': len([a for a in applications if a.status == 'Shortlisted']),
        'selected': len([a for a in applications if a.status == 'Selected']),
        'rejected': len([a for a in applications if a.status == 'Rejected'])
    }
    
    return render_template('student/history.html',
                         applications=applications_pagination.items,
                         pagination=applications_pagination,
                         stats=stats)

@student_bp.route('/drive/<int:drive_id>')
@login_required
@role_required('student')
def drive_details(drive_id):
    """View detailed information about a specific drive"""
    drive = PlacementDrive.query.get_or_404(drive_id)
    
    # Check if student has applied
    application = Application.query.filter_by(
        student_id=current_user.id,
        drive_id=drive_id
    ).first()
    
    # Check eligibility
    eligibility = {
        'cgpa': not drive.min_cgpa or (current_user.cgpa and current_user.cgpa >= drive.min_cgpa),
        'branch': not drive.allowed_branches or (current_user.branch and 
                 current_user.branch in [b.strip() for b in drive.allowed_branches.split(',')]),
        'deadline': not drive.application_deadline or datetime.now() <= drive.application_deadline
    }
    
    return render_template('student/drive_details.html',
                         drive=drive,
                         application=application,
                         eligibility=eligibility)

# API Endpoints
@student_bp.route('/api/applications')
@login_required
@role_required('student')
def api_applications():
    """Get student's applications data"""
    applications = Application.query.filter_by(student_id=current_user.id).all()
    return jsonify([{
        'id': a.id,
        'drive_title': a.drive.job_title,
        'company_name': a.drive.company.company_name,
        'application_date': a.application_date.strftime('%Y-%m-%d'),
        'status': a.status
    } for a in applications])

@student_bp.route('/api/drives')
@login_required
@role_required('student')
def api_drives():
    """Get available drives data"""
    drives = PlacementDrive.query.filter_by(status='Approved').all()
    applied_drive_ids = [app.drive_id for app in 
                        Application.query.filter_by(student_id=current_user.id).all()]
    
    return jsonify([{
        'id': d.id,
        'company_name': d.company.company_name,
        'job_title': d.job_title,
        'job_description': d.job_description,
        'eligibility_criteria': d.eligibility_criteria,
        'min_cgpa': d.min_cgpa,
        'allowed_branches': d.allowed_branches,
        'salary_package': d.salary_package,
        'location': d.location,
        'application_deadline': d.application_deadline.strftime('%Y-%m-%d') if d.application_deadline else None,
        'created_at': d.created_at.strftime('%Y-%m-%d') if d.created_at else None,
        'has_applied': d.id in applied_drive_ids
    } for d in drives])