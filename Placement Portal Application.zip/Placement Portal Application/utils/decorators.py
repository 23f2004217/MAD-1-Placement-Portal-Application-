"""
Custom decorators for authentication, authorization, and validation
"""
from functools import wraps
from flask import session, flash, redirect, url_for, request
from flask_login import current_user

def role_required(role):
    """
    Decorator to ensure user has the required role
    
    Args:
        role (str): Required role ('admin', 'company', 'student')
    """
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not current_user.is_authenticated:
                flash('Please log in to access this page', 'warning')
                return redirect(url_for('auth.login'))
            
            if session.get('user_type') != role:
                flash('Access denied. Insufficient permissions.', 'danger')
                return redirect(url_for('auth.login'))
            
            # Additional checks for company and student
            if role == 'company' and hasattr(current_user, 'is_blacklisted'):
                if current_user.is_blacklisted:
                    flash('Your account has been deactivated', 'danger')
                    return redirect(url_for('auth.login'))
            
            if role == 'student' and hasattr(current_user, 'is_blacklisted'):
                if current_user.is_blacklisted:
                    flash('Your account has been deactivated', 'danger')
                    return redirect(url_for('auth.login'))
            
            return f(*args, **kwargs)
        return decorated_function
    return decorator

def validate_form_data(f):
    """
    Decorator to validate form data is present
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if request.method == 'POST':
            # Check if form data exists
            if not request.form:
                flash('No form data received', 'danger')
                return redirect(request.url)
        
        return f(*args, **kwargs)
    return decorated_function

def admin_required(f):
    """
    Shorthand decorator for admin-only routes
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or session.get('user_type') != 'admin':
            flash('Admin access required', 'danger')
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)
    return decorated_function

def company_approved_required(f):
    """
    Decorator to ensure company is approved
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if (session.get('user_type') == 'company' and 
            hasattr(current_user, 'approval_status') and 
            current_user.approval_status != 'Approved'):
            flash('Your company account is pending approval', 'warning')
            return redirect(url_for('company.dashboard'))
        return f(*args, **kwargs)
    return decorated_function