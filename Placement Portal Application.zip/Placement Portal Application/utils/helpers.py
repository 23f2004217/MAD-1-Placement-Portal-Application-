"""
Helper functions for validation, file handling, and common operations
"""
from datetime import datetime
import os

# File upload configuration
ALLOWED_EXTENSIONS = {'pdf', 'doc', 'docx'}
MAX_FILE_SIZE = 16 * 1024 * 1024  # 16MB

def validate_cgpa(cgpa):
    """
    Validate CGPA is within acceptable range
    
    Args:
        cgpa (float): CGPA value to validate
        
    Returns:
        bool: True if valid, False otherwise
    """
    try:
        cgpa_float = float(cgpa)
        return 0.0 <= cgpa_float <= 10.0
    except (ValueError, TypeError):
        return False

def validate_graduation_year(year):
    """
    Validate graduation year is within acceptable range
    
    Args:
        year (int): Graduation year to validate
        
    Returns:
        bool: True if valid, False otherwise
    """
    try:
        year_int = int(year)
        current_year = datetime.now().year
        return current_year <= year_int <= current_year + 10
    except (ValueError, TypeError):
        return False

def validate_deadline(deadline):
    """
    Validate deadline is not in the past
    
    Args:
        deadline (datetime): Deadline to validate
        
    Returns:
        bool: True if valid, False otherwise
    """
    if not deadline:
        return True
    return deadline >= datetime.now()

def allowed_file(filename):
    """
    Check if file extension is allowed
    
    Args:
        filename (str): Name of the file
        
    Returns:
        bool: True if allowed, False otherwise
    """
    return ('.' in filename and 
            filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS)

def get_file_size(file):
    """
    Get file size in bytes
    
    Args:
        file: File object
        
    Returns:
        int: File size in bytes
    """
    file.seek(0, os.SEEK_END)
    size = file.tell()
    file.seek(0)
    return size

def validate_file_upload(file):
    """
    Comprehensive file upload validation
    
    Args:
        file: File object from request
        
    Returns:
        tuple: (is_valid, error_message)
    """
    if not file or not file.filename:
        return False, "No file selected"
    
    if not allowed_file(file.filename):
        return False, "Invalid file type. Only PDF, DOC, and DOCX files are allowed"
    
    file_size = get_file_size(file)
    if file_size > MAX_FILE_SIZE:
        return False, f"File too large. Maximum size is {MAX_FILE_SIZE // (1024*1024)}MB"
    
    return True, None

def get_pagination_info(pagination):
    """
    Get pagination information for templates
    
    Args:
        pagination: SQLAlchemy pagination object
        
    Returns:
        dict: Pagination information
    """
    return {
        'has_prev': pagination.has_prev,
        'prev_num': pagination.prev_num,
        'has_next': pagination.has_next,
        'next_num': pagination.next_num,
        'page': pagination.page,
        'pages': pagination.pages,
        'per_page': pagination.per_page,
        'total': pagination.total
    }

def format_date(date_obj, format_str='%Y-%m-%d'):
    """
    Format datetime object to string
    
    Args:
        date_obj (datetime): Date object to format
        format_str (str): Format string
        
    Returns:
        str: Formatted date string or empty string if None
    """
    if date_obj:
        return date_obj.strftime(format_str)
    return ''

def sanitize_input(input_str):
    """
    Basic input sanitization
    
    Args:
        input_str (str): Input string to sanitize
        
    Returns:
        str: Sanitized string
    """
    if not input_str:
        return ''
    return input_str.strip()

def generate_unique_filename(original_filename, prefix=''):
    """
    Generate unique filename with timestamp
    
    Args:
        original_filename (str): Original filename
        prefix (str): Prefix to add
        
    Returns:
        str: Unique filename
    """
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    name, ext = os.path.splitext(original_filename)
    return f"{prefix}_{timestamp}_{name}{ext}" if prefix else f"{timestamp}_{name}{ext}"

def check_eligibility(student, drive):
    """
    Check if student is eligible for a placement drive
    
    Args:
        student: Student object
        drive: PlacementDrive object
        
    Returns:
        dict: Eligibility status with reasons
    """
    eligibility = {
        'eligible': True,
        'reasons': []
    }
    
    # Check CGPA
    if drive.min_cgpa and student.cgpa and student.cgpa < drive.min_cgpa:
        eligibility['eligible'] = False
        eligibility['reasons'].append(f'CGPA requirement not met (Required: {drive.min_cgpa}, Your CGPA: {student.cgpa})')
    
    # Check branch
    if drive.allowed_branches and student.branch:
        allowed_branches = [b.strip() for b in drive.allowed_branches.split(',')]
        if student.branch not in allowed_branches:
            eligibility['eligible'] = False
            eligibility['reasons'].append(f'Branch not eligible (Allowed: {drive.allowed_branches}, Your branch: {student.branch})')
    
    # Check deadline
    if drive.application_deadline and datetime.now() > drive.application_deadline:
        eligibility['eligible'] = False
        eligibility['reasons'].append('Application deadline has passed')
    
    return eligibility

def get_application_stats(applications):
    """
    Get statistics from applications list
    
    Args:
        applications: List of Application objects
        
    Returns:
        dict: Statistics
    """
    stats = {
        'total': len(applications),
        'applied': 0,
        'shortlisted': 0,
        'selected': 0,
        'rejected': 0
    }
    
    for app in applications:
        if app.status == 'Applied':
            stats['applied'] += 1
        elif app.status == 'Shortlisted':
            stats['shortlisted'] += 1
        elif app.status == 'Selected':
            stats['selected'] += 1
        elif app.status == 'Rejected':
            stats['rejected'] += 1
    
    return stats